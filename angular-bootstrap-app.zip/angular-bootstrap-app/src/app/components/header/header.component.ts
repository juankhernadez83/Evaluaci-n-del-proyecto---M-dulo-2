/*
  header.component.ts
  Requisito #7: Uso de @HostBinding en al menos un componente
  Requisito #4: Sintaxis {{ }} para cargar datos de variables TypeScript
*/

import { Component, HostBinding } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  /* Requisito #7: @HostBinding aplica la clase Bootstrap al elemento host <app-header> */
  @HostBinding('class') hostClass = 'w-100 d-block';

  /* Requisito #4: Variables TypeScript que se mostrarán con {{ }} en el template */
  appNombre: string = 'Mi Gestor de Tareas';
  appDescripcion: string = 'Organiza tus actividades de forma simple y elegante';
  version: string = '1.0.0';
  autor: string = 'Angular + Bootstrap';
}
