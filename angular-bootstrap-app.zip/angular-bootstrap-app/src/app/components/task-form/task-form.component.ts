/*
  components/task-form/task-form.component.ts

  Req #1:  @Output con EventEmitter
  Req #4:  FormBuilder configura el FormGroup con al menos 2 controles
  Req #7:  Validaciones requerido + personalizada parametrizable
*/

import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Item } from '../../models/item.model';
import { minPalabras, noCaracteresEspeciales } from '../../validators/custom.validators';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.scss']
})
export class TaskFormComponent implements OnInit {

  /*
    Req #1: EventEmitter decorado con @Output
    El componente padre escucha este evento con (tareaNueva)="onTareaNueva($event)"
  */
  @Output() tareaNueva = new EventEmitter<Item>();

  /* FormGroup que agrupa todos los controles del formulario */
  tareaForm!: FormGroup;

  private nextId = 100;

  constructor(
    /*
      Req #4: FormBuilder inyectado en el constructor
      Se usa para configurar el FormGroup de forma declarativa
    */
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    /*
      Req #4: Configuración del FormGroup con FormBuilder
      Se definen al menos 2 campos/controles con sus validadores
    */
    this.tareaForm = this.fb.group({

      /*
        Control 1: nombre
        - Req #7: Validators.required  → validación requerido
        - Req #7: minPalabras(2)       → validación personalizada parametrizable (mínimo 2 palabras)
        - Req #7: noCaracteresEspeciales → validación personalizada adicional
      */
      nombre: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          minPalabras(2),
          noCaracteresEspeciales
        ]
      ],

      /*
        Control 2: descripcion
        - Req #7: Validators.required
        - Req #7: minPalabras(3) — debe tener al menos 3 palabras
      */
      descripcion: [
        '',
        [
          Validators.required,
          minPalabras(3)
        ]
      ],

      /* Control 3: categoria (requerido) */
      categoria: ['Estudio', Validators.required]
    });
  }

  /* Getter shortcuts para acceder a controles en el template */
  get nombre() { return this.tareaForm.get('nombre')!; }
  get descripcion() { return this.tareaForm.get('descripcion')!; }
  get categoria() { return this.tareaForm.get('categoria')!; }

  /*
    Al hacer submit, si el form es válido:
    - Crea un objeto Item
    - Emite el EventEmitter @Output para que el padre lo reciba
    - Resetea el formulario
  */
  onSubmit(): void {
    if (this.tareaForm.invalid) {
      /* Marcar todos los campos como touched para mostrar errores */
      this.tareaForm.markAllAsTouched();
      return;
    }

    const nuevaTarea: Item = {
      id: this.nextId++,
      nombre: this.tareaForm.value.nombre.trim(),
      descripcion: this.tareaForm.value.descripcion.trim(),
      categoria: this.tareaForm.value.categoria,
      fechaCreacion: new Date()
    };

    /* Req #1: Emisión del EventEmitter @Output hacia el componente padre */
    this.tareaNueva.emit(nuevaTarea);

    this.tareaForm.reset({ categoria: 'Estudio' });
  }
}
