/*
  item-list.component.ts
  
  Requisito #5:  Componente contenedor de un listado de objetos con array de elementos
  Requisito #7:  @HostBinding en este componente
  Requisito #9:  Función que se invoca al hacer click en submit para agregar ítem
  Requisito #10: Función que agrega al array y actualiza reactivamente la UI
*/

import { Component, HostBinding } from '@angular/core';
import { Item } from '../../models/item.model';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss']
})
export class ItemListComponent {

  /* 
    Requisito #7: @HostBinding - aplica clases Bootstrap directamente al elemento host
    Esto agrega class="container py-3" al elemento <app-item-list> en el DOM
  */
  @HostBinding('class') hostClass = 'container py-3 d-block';

  /* Título del componente - usado con {{ }} en el template */
  titulo: string = 'Lista de Tareas';
  subtitulo: string = 'Gestiona tus actividades pendientes';

  /* Contador para mensajes de estado */
  mensajeExito: string = '';

  /* 
    Requisito #5: Array de elementos (objetos Item) que se muestran en el listado
    Datos iniciales precargados
  */
  items: Item[] = [
    {
      id: 1,
      nombre: 'Estudiar Angular',
      descripcion: 'Repasar directivas, componentes y servicios',
      categoria: 'Estudio',
      fechaCreacion: new Date('2024-01-10')
    },
    {
      id: 2,
      nombre: 'Integrar Bootstrap',
      descripcion: 'Aplicar clases de Bootstrap en templates HTML',
      categoria: 'Desarrollo',
      fechaCreacion: new Date('2024-01-11')
    },
    {
      id: 3,
      nombre: 'Practicar NgFor',
      descripcion: 'Usar la directiva *ngFor para iterar listas',
      categoria: 'Práctica',
      fechaCreacion: new Date('2024-01-12')
    },
    {
      id: 4,
      nombre: 'Implementar formularios',
      descripcion: 'Usar variables de plantilla con # en formularios Angular',
      categoria: 'Desarrollo',
      fechaCreacion: new Date('2024-01-13')
    }
  ];

  /* Contador para generar IDs únicos */
  private proximoId: number = 5;

  /*
    Requisito #9 y #10: Función invocada desde el botón submit del formulario.
    Recibe los datos capturados con variables de plantilla # y agrega al array.
    Al modificar el array, Angular detecta el cambio y actualiza la UI reactivamente.
  */
  agregarItem(nombre: string, descripcion: string, categoria: string): void {
    // Validación básica
    if (!nombre.trim() || !descripcion.trim()) {
      return;
    }

    /* 
      Requisito #10: Se crea el nuevo item y se agrega al array con push().
      Angular detecta el cambio y re-renderiza el *ngFor automáticamente (reactividad).
    */
    const nuevoItem: Item = {
      id: this.proximoId++,
      nombre: nombre.trim(),
      descripcion: descripcion.trim(),
      categoria: categoria || 'General',
      fechaCreacion: new Date()
    };

    this.items.push(nuevoItem);

    /* Mensaje de confirmación usando interpolación {{ }} */
    this.mensajeExito = `✅ "${nuevoItem.nombre}" fue agregado correctamente.`;

    /* Limpiar mensaje después de 3 segundos */
    setTimeout(() => {
      this.mensajeExito = '';
    }, 3000);
  }

  /* Función para eliminar un ítem por id */
  eliminarItem(id: number): void {
    this.items = this.items.filter(item => item.id !== id);
  }

  /* Getter para mostrar cantidad total con {{ }} */
  get totalItems(): number {
    return this.items.length;
  }
}
