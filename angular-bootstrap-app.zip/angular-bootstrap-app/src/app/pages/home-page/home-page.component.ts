/*
  pages/home-page/home-page.component.ts

  Req #6: Componente PADRE que contiene el componente hijo (app-task-form)
  y "recibe" el evento emitido por el @Output del hijo.
*/

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Item } from '../../models/item.model';
import { agregarTarea, eliminarTarea } from '../../store/actions/task.actions';
import { selectAllTasks } from '../../store/selectors/app.selectors';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  /* Observable del store NgRx con las tareas */
  tareas$!: Observable<Item[]>;

  constructor(private store: Store) {}

  ngOnInit(): void {
    this.tareas$ = this.store.select(selectAllTasks);
  }

  /*
    Req #6: Este método es invocado cuando el componente hijo (app-task-form)
    emite el evento @Output "tareaNueva".
    En el HTML del padre se usa: (tareaNueva)="onTareaNueva($event)"
  */
  onTareaNueva(item: Item): void {
    /* Despacha la action al store NgRx para agregar la tarea */
    this.store.dispatch(agregarTarea({ item }));
  }

  eliminarTarea(id: number): void {
    this.store.dispatch(eliminarTarea({ id }));
  }
}
