/*
  pages/votes-page/votes-page.component.ts

  Req #10: Funcionalidad de voto positivo y negativo implementada con NgRx/Redux.
  Cada elemento tiene su propio contador de votos.
*/

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { VoteItem } from '../../models/item.model';
import {
  agregarVoteItem,
  eliminarVoteItem,
  votarPositivo,
  votarNegativo
} from '../../store/actions/task.actions';
import { selectAllVotes } from '../../store/selectors/app.selectors';

@Component({
  selector: 'app-votes-page',
  templateUrl: './votes-page.component.html',
  styleUrls: ['./votes-page.component.scss']
})
export class VotesPageComponent implements OnInit {

  /* Observable del store con los items de votación */
  voteItems$!: Observable<VoteItem[]>;

  /* Formulario reactivo para agregar nuevo ítem de votación */
  voteForm!: FormGroup;

  private nextId = 100;

  constructor(
    private store: Store,
    private fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.voteItems$ = this.store.select(selectAllVotes);

    /* FormGroup para agregar ítems de votación */
    this.voteForm = this.fb.group({
      titulo: ['', [Validators.required, Validators.minLength(5)]],
      descripcion: ['', Validators.required]
    });
  }

  get titulo() { return this.voteForm.get('titulo')!; }
  get descripcion() { return this.voteForm.get('descripcion')!; }

  agregarItem(): void {
    if (this.voteForm.invalid) {
      this.voteForm.markAllAsTouched();
      return;
    }
    const item: VoteItem = {
      id: this.nextId++,
      titulo: this.voteForm.value.titulo.trim(),
      descripcion: this.voteForm.value.descripcion.trim(),
      votosPositivos: 0,
      votosNegativos: 0
    };
    this.store.dispatch(agregarVoteItem({ item }));
    this.voteForm.reset();
  }

  /* Req #10: Despacha action de voto positivo al store */
  onVotarPositivo(id: number): void {
    this.store.dispatch(votarPositivo({ id }));
  }

  /* Req #10: Despacha action de voto negativo al store */
  onVotarNegativo(id: number): void {
    this.store.dispatch(votarNegativo({ id }));
  }

  eliminarItem(id: number): void {
    this.store.dispatch(eliminarVoteItem({ id }));
  }

  /* Calcula el porcentaje de votos positivos para la barra de progreso */
  calcularPorcentaje(item: VoteItem): number {
    const total = item.votosPositivos + item.votosNegativos;
    if (total === 0) return 50;
    return Math.round((item.votosPositivos / total) * 100);
  }
}
