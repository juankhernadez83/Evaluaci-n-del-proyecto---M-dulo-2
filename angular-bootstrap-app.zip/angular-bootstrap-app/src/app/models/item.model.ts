/* item.model.ts */

export interface Item {
  id: number;
  nombre: string;
  descripcion: string;
  categoria: string;
  fechaCreacion: Date;
}

/* Modelo para el listado con votos (Req #10) */
export interface VoteItem {
  id: number;
  titulo: string;
  descripcion: string;
  votosPositivos: number;
  votosNegativos: number;
}
