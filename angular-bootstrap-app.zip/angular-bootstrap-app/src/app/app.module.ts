/*
  app.module.ts

  Req #2: Configuración de rutas importando AppRoutingModule
  Configuración del store NgRx con los reducers
*/

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

/* NgRx Store */
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';

/* Routing — Req #2 */
import { AppRoutingModule } from './app-routing.module';

/* Reducers */
import { taskReducer } from './store/reducers/task.reducer';
import { voteReducer } from './store/reducers/vote.reducer';

/* Componentes */
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { TaskFormComponent } from './components/task-form/task-form.component';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { VotesPageComponent } from './pages/votes-page/votes-page.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TaskFormComponent,
    HomePageComponent,
    VotesPageComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,

    StoreModule.forRoot({
      tasks: taskReducer,
      votes: voteReducer
    }),
    StoreDevtoolsModule.instrument({ maxAge: 25 })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
