/*
  validators/custom.validators.ts

  Req #7: Validación personalizada y parametrizable
*/

import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/*
  minPalabras(n): validador parametrizable que exige al menos N palabras.
  Es una "validator factory" — recibe un parámetro y retorna un ValidatorFn.
*/
export function minPalabras(minimo: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor: string = control.value || '';
    const palabras = valor.trim().split(/\s+/).filter(p => p.length > 0);

    if (palabras.length < minimo) {
      /* Retorna un objeto de error con el parámetro, para usarlo en el template */
      return {
        minPalabras: {
          requerido: minimo,
          actual: palabras.length
        }
      };
    }
    return null; // null = válido
  };
}

/*
  noCaracteresEspeciales: validador que rechaza símbolos como <, >, &, etc.
*/
export function noCaracteresEspeciales(control: AbstractControl): ValidationErrors | null {
  const valor: string = control.value || '';
  const patron = /[<>&"'`]/;

  if (patron.test(valor)) {
    return { caracteresEspeciales: true };
  }
  return null;
}
