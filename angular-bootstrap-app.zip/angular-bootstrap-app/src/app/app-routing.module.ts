/*
  app-routing.module.ts

  Req #2: Configuración de rutas con:
  - Un path con redirectTo
  - Un path que indica un component
*/

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomePageComponent } from './pages/home-page/home-page.component';
import { VotesPageComponent } from './pages/votes-page/votes-page.component';

/*
  Req #2: Definición de rutas del proyecto
*/
const routes: Routes = [

  /* Ruta con redirect: path vacío redirige a /tareas */
  {
    path: '',
    redirectTo: 'tareas',
    pathMatch: 'full'
  },

  /* Ruta que indica un component: /tareas → HomePageComponent */
  {
    path: 'tareas',
    component: HomePageComponent
  },

  /* Ruta que indica un component: /votos → VotesPageComponent */
  {
    path: 'votos',
    component: VotesPageComponent
  },

  /* Wildcard: cualquier ruta no encontrada redirige a /tareas */
  {
    path: '**',
    redirectTo: 'tareas'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
