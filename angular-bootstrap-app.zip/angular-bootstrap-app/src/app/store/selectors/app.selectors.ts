/*
  store/selectors/app.selectors.ts
*/

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TaskState } from '../reducers/task.reducer';
import { VoteState } from '../reducers/vote.reducer';

/* Selectors para tareas */
export const selectTaskState = createFeatureSelector<TaskState>('tasks');
export const selectAllTasks = createSelector(selectTaskState, s => s.items);

/* Selectors para votos */
export const selectVoteState = createFeatureSelector<VoteState>('votes');
export const selectAllVotes = createSelector(selectVoteState, s => s.items);
