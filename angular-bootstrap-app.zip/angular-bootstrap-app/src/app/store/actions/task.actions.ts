/*
  store/actions/task.actions.ts

  Req #9: Al menos un reducer con 2 actions para agregar y borrar elementos
*/

import { createAction, props } from '@ngrx/store';
import { Item, VoteItem } from '../../models/item.model';

/* ── TASK ACTIONS (Req #9: agregar y borrar) ── */
export const agregarTarea = createAction(
  '[Tasks] Agregar Tarea',
  props<{ item: Item }>()
);

export const eliminarTarea = createAction(
  '[Tasks] Eliminar Tarea',
  props<{ id: number }>()
);

/* ── VOTE ACTIONS (Req #10: voto a favor y voto negativo) ── */
export const agregarVoteItem = createAction(
  '[Votes] Agregar Item',
  props<{ item: VoteItem }>()
);

export const eliminarVoteItem = createAction(
  '[Votes] Eliminar Item',
  props<{ id: number }>()
);

export const votarPositivo = createAction(
  '[Votes] Votar Positivo',
  props<{ id: number }>()
);

export const votarNegativo = createAction(
  '[Votes] Votar Negativo',
  props<{ id: number }>()
);
