/*
  store/reducers/task.reducer.ts

  Req #9: Reducer con 2 actions para agregar y borrar de la colección
*/

import { createReducer, on } from '@ngrx/store';
import { Item } from '../../models/item.model';
import { agregarTarea, eliminarTarea } from '../actions/task.actions';

export interface TaskState {
  items: Item[];
}

export const initialTaskState: TaskState = {
  items: [
    {
      id: 1,
      nombre: 'Estudiar Angular',
      descripcion: 'Repasar directivas, componentes y servicios',
      categoria: 'Estudio',
      fechaCreacion: new Date('2024-01-10')
    },
    {
      id: 2,
      nombre: 'Integrar Bootstrap',
      descripcion: 'Aplicar clases Bootstrap en los templates',
      categoria: 'Desarrollo',
      fechaCreacion: new Date('2024-01-11')
    },
    {
      id: 3,
      nombre: 'Configurar NgRx',
      descripcion: 'Implementar el store con actions y reducers',
      categoria: 'Desarrollo',
      fechaCreacion: new Date('2024-01-12')
    }
  ]
};

/* Req #9: Reducer con las 2 actions obligatorias: agregar y borrar */
export const taskReducer = createReducer(
  initialTaskState,

  /* Action 1: Agregar tarea al array */
  on(agregarTarea, (state, { item }) => ({
    ...state,
    items: [...state.items, item]
  })),

  /* Action 2: Eliminar tarea del array por id */
  on(eliminarTarea, (state, { id }) => ({
    ...state,
    items: state.items.filter(i => i.id !== id)
  }))
);
