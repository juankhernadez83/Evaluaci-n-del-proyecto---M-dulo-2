/*
  store/reducers/vote.reducer.ts

  Req #10: Reducer para votos positivos y negativos por elemento
*/

import { createReducer, on } from '@ngrx/store';
import { VoteItem } from '../../models/item.model';
import {
  agregarVoteItem,
  eliminarVoteItem,
  votarPositivo,
  votarNegativo
} from '../actions/task.actions';

export interface VoteState {
  items: VoteItem[];
}

export const initialVoteState: VoteState = {
  items: [
    { id: 1, titulo: 'Angular vs React', descripcion: '¿Cuál framework prefieres para proyectos empresariales?', votosPositivos: 12, votosNegativos: 4 },
    { id: 2, titulo: 'TypeScript es obligatorio', descripcion: '¿Debería ser TypeScript el estándar en todo proyecto web?', votosPositivos: 20, votosNegativos: 3 },
    { id: 3, titulo: 'NgRx para todo', descripcion: '¿Es NgRx necesario en aplicaciones pequeñas?', votosPositivos: 5, votosNegativos: 15 },
    { id: 4, titulo: 'Bootstrap vs Tailwind', descripcion: '¿Qué framework de CSS recomendarías a principiantes?', votosPositivos: 9, votosNegativos: 7 }
  ]
};

/* Req #10: Reducer con actions de voto positivo y negativo */
export const voteReducer = createReducer(
  initialVoteState,

  on(agregarVoteItem, (state, { item }) => ({
    ...state,
    items: [...state.items, item]
  })),

  on(eliminarVoteItem, (state, { id }) => ({
    ...state,
    items: state.items.filter(i => i.id !== id)
  })),

  /* Action voto positivo: incrementa votosPositivos del item con ese id */
  on(votarPositivo, (state, { id }) => ({
    ...state,
    items: state.items.map(item =>
      item.id === id
        ? { ...item, votosPositivos: item.votosPositivos + 1 }
        : item
    )
  })),

  /* Action voto negativo: incrementa votosNegativos del item con ese id */
  on(votarNegativo, (state, { id }) => ({
    ...state,
    items: state.items.map(item =>
      item.id === id
        ? { ...item, votosNegativos: item.votosNegativos + 1 }
        : item
    )
  }))
);
